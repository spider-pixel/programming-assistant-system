<?php

define("GEMINI_API_KEY", "AQ.Ab8RN6I9lTMhw1RjC8yT_QabZQqqpwnftqO5tIE4S_yV03myfw");

?>